#!/usr/bin/env bash

skel=./base

USAGE="Usage: `basename $0` [-h] [-c] [-u username] [-k skel]"

# Parse command line options.
while getopts "hcu:k:" OPT; do
    case "$OPT" in
        h)
            echo $USAGE
            exit 0
            ;;
        c)
            clearfirst=true
            ;;
        u)
            username=${OPTARG}
            ;;
        k)
            skel=${OPTARG}
            ;;
        \?)
            # getopts issues an error message
            echo $USAGE >&2
            exit 1
            ;;
    esac
done

if [ -n "$username" ];
then
   userdir="/home/$username"
   if [ -n "$clearfirst" ] && [ userdir != "/" ] && [ userdir != "/home" ] && [ userdir != "/home/" ];
   then
      echo "Deleting everthing from current user directory"
      rm -rf $userdir/*
   fi
   echo "Copying the base folder to the user directory"
   cp -r $skel/. $userdir
   echo "Changing owner of all files"
   chown -R $username:$username $userdir
else
   echo "Please specify a username using the -u option"
fi

