#!/usr/bin/env bash

prefix="test"
count="5"
csvfile="logins.csv"
create=false
basefolder=./base
pwlen="12"

USAGE="Usage: `basename $0` [-h] [-p prefix] [-n count] [-f csvfile] [-c create][-k skel] [-l pwlength]"

# Parse command line options.
while getopts "hcp:f:n:k:l:" OPT; do
    case "$OPT" in
        h)
            echo $USAGE
            exit 0
            ;;
        p)
            prefix=${OPTARG}
            ;;
        c)  
            create=true
            ;;
        n)
            count=${OPTARG}
            ;;
        f)
            csvfile=${OPTARG}
            ;;
	k)  
            basefolder=${OPTARG}
	    ;;
        l)
            pwlen=${OPTARG}
	    ;;
        \?)
            # getopts issues an error message
            echo $USAGE >&2
            exit 1
            ;;
    esac
done

echo "Username,Password" > $csvfile
for i in `seq 1 $count`
do
password=$(openssl rand -base64 $pwlen | head -c $pwlen)
if [ $count = "1" ]
then
username="$prefix"
else
username="$prefix$i"
fi
echo "$username,$password" >> $csvfile
if $create
then
   useradd -m $username
   echo $username:$password | chpasswd
   userdir=/home/$username
   cp -r $basefolder/. $userdir
   chown -R $username:$username $userdir

fi
done

echo "$count users generated and written to $csvfile"

if $create
then
   echo "Users were created and added to the system"
else
   echo "This was just a test run. To actually add users use the -c flag"
fi

