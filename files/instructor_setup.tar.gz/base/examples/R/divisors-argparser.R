# Load the argparser library and install it if it is missing
if (!require("argparser", quiet=TRUE)) {
   install.packages("argparser")
   library(argparser)
}

# First we build up the argument parser
parser <- arg_parser("Find numbers that are divisible by a list of divisors")
parser <- add_argument(parser, "--bound", short="-b", help="An upper bound on which numbers to check", default=100)
parser <- add_argument(parser, "--divs", short="-d", help="A list of divisors to check for", nargs=Inf)


# Read the command line arguments and parse the arguments
args <- commandArgs(trailingOnly=TRUE)
parsed_args <- parse_args(parser, args)

# Extract the parsed data
upper_bound <- as.numeric(parsed_args$bound)
divisors <- as.numeric(parsed_args$divs)

# Check if some divisors are given
if (any(is.na(divisors))) {
   cat("Please provide one or more divisors\n")
   quit()
}

result <- c()
for (i in 1:upper_bound) {
   divisable <- TRUE
   for (div in divisors) {
      if (i %% div != 0) {
         divisable <- FALSE
      }
   }
   if (divisable) {
      result <- append(result, c(i))
   }
}

cat("The following numbers are divisible by all of the divisors\n")
cat(paste(result, collapse=", "), "\n")

