stdin <- file("stdin", "r")
read_more <- TRUE
cat("What is the upper bound of numbers to be considered?\n")
upper_bound <- scan(file=stdin, what=integer(0), n=1, quiet=TRUE)
divisors <- c()
while (read_more) {
   cat("Enter a divisor you want to consider (or -1 if you are done)\n")
   div <- scan(file=stdin, what=integer(0), n=1, quiet=TRUE)
   if (div == -1) {
      read_more <- FALSE
   }
   else {
      divisors <- append(divisors, div)
   }
}

result <- c()
for (i in 1:upper_bound) {
   divisable <- TRUE
   for (div in divisors) {
      if (i %% div != 0) {
         divisable <- FALSE
      }
   }
   if (divisable) {
      result <- append(result, c(i))
   }
}

cat("The following numbers are divisible by all of the divisors\n")
cat(paste(result, collapse=", "), "\n")

