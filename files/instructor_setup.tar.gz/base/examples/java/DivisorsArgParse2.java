import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;


import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

@Command(description="Find numbers that are divisible by a list of divisors")
public class DivisorsArgParse2 implements Runnable {

   @Option(names={"--bound","-b"}, defaultValue="100", description="An upper bound on which numbers to check")
   protected int upperBound;

   @Option(names={"--divs","-d"}, required=true, arity="1..*", description="A list of divisors to check for")
   protected List<Integer> divisors;

   @Override
   public void run() {
      List<Integer> result = getDivisors();
      System.out.println("The following numbers adhere to the rules defined");
      System.out.println(result);
   }

   public List<Integer> getDivisors() {
      List<Integer> result = new ArrayList<>();
      for (int i=1; i < upperBound; i++) {
         boolean divisable = true;
         for (int div : divisors) {
            if (i%div != 0) {
               divisable = false;
            }
         }
         if (divisable) {
            result.add(i);
         }
      }
      return result;
   }

   public static void main(String [] args) {
      // Create an empty DivisorsArgParse object
      DivisorsArgParse2 myObj = new DivisorsArgParse2();
      // Create a picocli CommandLine object that will configure myObj and then pass it the arguments
      CommandLine cli = new CommandLine(myObj);
      cli.execute(args);
   }
}
