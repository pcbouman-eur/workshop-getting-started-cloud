
# These are the parameters
upper_bound = 100
divisors = [3, 5]

# Here we search for suitable numbers
result = []
for i in range(1,upper_bound):
   divisable = True
   for div in divisors:
      if i % div != 0:
         divisable = False
   if divisable:
      result.append(i)

print("The following numbers are divisible by all of the divisors")
print(result)
