
upper_bound = input("What is the upper bound of numbers to be considered?\n")
upper_bound = int(upper_bound)

divisors = []
read_more = True
while read_more:
   next = input("Enter a divisor you want to consider (or -1 if you are done)\n")
   next = int(next)
   if next == -1:
      read_more = False
   else:
      divisors.append(next)

result = []
for i in range(1,upper_bound):
   divisable = True
   for div in divisors:
      if i % div != 0:
         divisable = False
   if divisable:
      result.append(i)

print("The following numbers are divisible by all of the divisors")
print(result)
