import java.util.List;
import java.util.ArrayList;

public class DivisorsArgs {

   public static void main(String [] args) {
      int upperBound = Integer.parseInt(args[0]);
      List<Integer> divisors = new ArrayList<>();
      for (int i=1; i < args.length; i++) {
         divisors.add(Integer.parseInt(args[i]));
      }
      List<Integer> result = getDivisors(upperBound, divisors);
      System.out.println("The following numbers are divisible by all of the divisors");
      System.out.println(result);
   }


   public static List<Integer> getDivisors(int upperBound, List<Integer> divisors) {
      List<Integer> result = new ArrayList<>();
      for (int i=1; i < upperBound; i++) {
         boolean divisable = true;
         for (int div : divisors) {
            if (i%div != 0) {
               divisable = false;
            }
         }
         if (divisable) {
            result.add(i);
         }
      }
      return result;
   }


}
