import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class DivisorsStdIn {

   public static void main(String [] args) {
      try (Scanner scan = new Scanner(System.in)) {
         System.out.println("What is the upper bound of numbers to be considered?");
         int upperBound = scan.nextInt();
         List<Integer> divisors = new ArrayList<>();

         boolean readMore = true;
         while (readMore) {
            System.out.println("Enter a divisor you want to consider (or -1 if you are done)");
            int div = scan.nextInt();
            if (div == -1) {
               readMore = false;
            }
            else {
               divisors.add(div);
            }
         }

         List<Integer> result = getDivisors(upperBound, divisors);
         System.out.println("The following numbers are divisible by all of the divisors");
         System.out.println(result);
      }
   }

   public static List<Integer> getDivisors(int upperBound, List<Integer> divisors) {
      List<Integer> result = new ArrayList<>();
      for (int i=1; i < upperBound; i++) {
         boolean divisable = true;
         for (int div : divisors) {
            if (i%div != 0) {
               divisable = false;
            }
         }
         if (divisable) {
            result.add(i);
         }
      }
      return result;
   }

}
