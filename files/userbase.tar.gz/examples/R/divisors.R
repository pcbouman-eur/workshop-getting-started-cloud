upper_bound <- 100
divisors <- c(3, 5)

result <- c()
for (i in 1:upper_bound) {
   divisable <- TRUE
   for (div in divisors) {
      if (i %% div != 0) {
         divisable <- FALSE
      }
   }
   if (divisable) {
      result <- append(result, c(i))
   }
}

cat("The following numbers are divisible by all of the divisors\n")
cat(paste(result, collapse=", "), "\n")

