args <- commandArgs(trailingOnly=TRUE)
print(args)
